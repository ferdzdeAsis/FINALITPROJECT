<?php
if(isset($_POST['submit'])){
	if(!empty($_POST['email']) || !empty($_POST['password'])){

	$email = $_POST['email'];
	$password = $_POST['password'];

	ob_start();   // output buffer.
	include ('config.php'); //dbase connect.

	//remove slashes('/') of the string. 
	$email = stripslashes($email);
	$password = stripslashes($password);
	//escapes special characters in the string for use in SQL.
	$email = mysqli_real_escape_string($connect, $email);
	$password = mysqli_real_escape_string($connect, $password);
	
	$sqlTenant =  "SELECT * FROM tenant WHERE email = '$email' AND password = '$password'";

	//query from dbase.
	$resultTenant = mysqli_query($connect, $sqlTenant);

	//count rows. if == 1 then it exist.
	$countTenant = mysqli_num_rows($resultTenant);
	
	if($countTenant == 1){
		if ( $countTenant >= 1) {
					$rowsTenant = mysqli_fetch_array($resultTenant);
					$_SESSION['user_id'] = $rowsTenant['id'];
					$_SESSION['user_email'] = $rowsTenant['email'];
				
					header("Location: concerns-tenant.php");
		}
	}else{
				  echo "<script>
				  alert('Incorrect Email Address or Password, Please try again.');
				  window.location.href='login-tenant.php';
				  </script>"; 
			}
		mysqli_close($connect);
		ob_end_flush(); //clear buffer.
	}
}