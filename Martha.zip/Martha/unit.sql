use marthagoshen;

select * from unit;

INSERT INTO `marthagoshen`.`unit` (`unitid`, `building`, `status`) VALUES ('5LE-E', 'harvard', 'open'); 

