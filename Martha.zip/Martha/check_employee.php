<?php
if(isset($_POST['submit'])){
	if(!empty($_POST['email']) || !empty($_POST['password'])){

	$email = $_POST['email'];
	$password = $_POST['password'];

	ob_start();   // output buffer.
	include ('config.php'); //dbase connect.

	//remove slashes('/') of the string. 
	$email = stripslashes($email);
	$password = stripslashes($password);
	//escapes special characters in the string for use in SQL.
	$email = mysqli_real_escape_string($connect, $email);
	$password = mysqli_real_escape_string($connect, $password);

	$sqlEmployee =  "SELECT * FROM employee WHERE email = '$email' AND password = '$password'";

	//query from dbase.
	$resultEmployee = mysqli_query($connect, $sqlEmployee);

	//count rows. if ==1 then exists.
	$countEmployee = mysqli_num_rows($resultEmployee);
		
		if ($countEmployee >= 1){
			$rowsEmployee = mysqli_fetch_array($resultEmployee);
			$_SESSION['user_id'] = $rowsEmployee['empid'];
			$_SESSION['user_email'] = $rowsEmployee['email'];

			header("Location: Rent.php");
		}else{
			echo "<script>
				alert('Incorrect Email Address or Password, Please try again.');
				window.location.href='login-employee.php';
				</script>"; 
		}
		mysqli_close($connect);
		ob_end_flush(); //clear buffer.
	}
}