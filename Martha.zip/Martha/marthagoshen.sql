-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 01, 2019 at 06:13 AM
-- Server version: 5.5.60
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `marthagoshen`
--

-- --------------------------------------------------------

--
-- Table structure for table `billing`
--

DROP TABLE IF EXISTS `billing`;
CREATE TABLE IF NOT EXISTS `billing` (
  `billid` int(10) NOT NULL AUTO_INCREMENT,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `duedate` datetime NOT NULL,
  `totalamount` int(10) NOT NULL,
  `type` enum('rent','utility','maintenance','') NOT NULL,
  `empid` int(11) NOT NULL,
  `unitId` varchar(10) NOT NULL,
  `building` enum('harvard','princeton','wharton','') NOT NULL,
  PRIMARY KEY (`billid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billing`
--

INSERT INTO `billing` (`billid`, `date`, `duedate`, `totalamount`, `type`, `empid`, `unitId`, `building`) VALUES
(1, '2019-05-26 02:43:31', '2019-06-10 17:00:00', 1245, 'rent', 2, '5LM-E', 'princeton');

-- --------------------------------------------------------

--
-- Table structure for table `concern`
--

DROP TABLE IF EXISTS `concern`;
CREATE TABLE IF NOT EXISTS `concern` (
  `concernid` int(10) NOT NULL AUTO_INCREMENT,
  `reporteddate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `description` varchar(70) NOT NULL,
  `timeavailable` time NOT NULL DEFAULT '00:00:00',
  `status` enum('done','processing') NOT NULL,
  `dateavailable` date NOT NULL DEFAULT '0000-00-00',
  `total` int(10) DEFAULT NULL,
  `id` int(8) NOT NULL,
  `response` varchar(70) NOT NULL,
  `feedback` varchar(70) NOT NULL,
  PRIMARY KEY (`concernid`),
  KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `concern`
--

INSERT INTO `concern` (`concernid`, `reporteddate`, `description`, `timeavailable`, `status`, `dateavailable`, `total`, `id`, `response`, `feedback`) VALUES
(1, '2019-06-01 03:43:33', 'broken door', '12:30:00', 'processing', '2019-06-05', NULL, 1, 'In the process of repairing', ''),
(2, '2019-06-01 06:11:32', 'broken pipes', '05:00:00', 'done', '2019-05-28', 800, 2, 'Fixed the pipes and cleaned the sink', '');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `empid` int(7) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `firstname` char(50) NOT NULL,
  `lastname` char(50) NOT NULL,
  `contact` varchar(11) DEFAULT NULL,
  `position` enum('admin','leasing officer','leasing manager','accounting officer','accounting manager','maintenance') NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`empid`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`empid`, `email`, `firstname`, `lastname`, `contact`, `position`, `password`) VALUES
(1, 'ferdinanddeasis@marthservices.com', 'Ferdinand II', 'De Asis', '09175057090', 'admin', 'ferdinand'),
(2, 'abigail@marthaservices.com', 'Abigail', 'Rubrico', '09875261895', 'accounting officer', 'abigailrubrico'),
(3, 'hazelignacio@marthaservices.com', 'Hazel', 'Ignacio', '09739486184', 'leasing manager', 'hazenacio'),
(4, 'drevasuncion@marthaservices.com', 'Drev', 'Asuncion', '09785261846', 'leasing officer', 'drevesper'),
(5, 'ephraim@marthaservices.com', 'Keynneth', 'Garcia', '09175688495', 'maintenance', 'raigarrr');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
CREATE TABLE IF NOT EXISTS `history` (
  `id` int(10) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `data` varchar(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `uniprice` int(6) NOT NULL,
  `itemid` int(11) NOT NULL,
  `idemp` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
CREATE TABLE IF NOT EXISTS `item` (
  `itemid` int(10) NOT NULL AUTO_INCREMENT,
  `item` varchar(50) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `description` text,
  `quantity` int(6) DEFAULT NULL,
  `unitprice` double DEFAULT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`itemid`),
  UNIQUE KEY `item` (`item`),
  UNIQUE KEY `item_2` (`item`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`itemid`, `item`, `brand`, `description`, `quantity`, `unitprice`, `date`) VALUES
(1, 'doorknob', 'Medeco', 'doorknob with a lock', 1, 250, '2018-05-26 05:38:00'),
(2, 'percolator', 'Dowell', '', 1, 450, '2018-05-16 16:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `requesteditem`
--

DROP TABLE IF EXISTS `requesteditem`;
CREATE TABLE IF NOT EXISTS `requesteditem` (
  `concernid` int(10) NOT NULL,
  `itemid` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `total` int(10) NOT NULL,
  `unitprice` int(10) NOT NULL,
  PRIMARY KEY (`concernid`,`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `requesteditem`
--

INSERT INTO `requesteditem` (`concernid`, `itemid`, `quantity`, `total`, `unitprice`) VALUES
(1, 1, 3, 750, 250);

-- --------------------------------------------------------

--
-- Table structure for table `tenant`
--

DROP TABLE IF EXISTS `tenant`;
CREATE TABLE IF NOT EXISTS `tenant` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `building` enum('harvard','princeton','wharton') NOT NULL,
  `unitid` varchar(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tenant`
--

INSERT INTO `tenant` (`id`, `email`, `firstname`, `lastname`, `password`, `contact`, `building`, `unitid`) VALUES
(1, 'jeffpaswick@marthaservices.com', 'Jeff', 'Paswick', 'jeffpaswick', '09065792344', 'princeton', '5LM-E'),
(2, 'yvonnemanuel@marthaservices.com', 'Yvonne', 'Manuel', 'yvonnemanuel12', '09302406268', 'wharton', '5LA-W'),
(3, 'apostoljohn@marthaservices.com', 'John Raphael', 'Apostol', 'raphpostol', '09516782905', 'harvard', '3RS-B');

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

DROP TABLE IF EXISTS `unit`;
CREATE TABLE IF NOT EXISTS `unit` (
  `unitId` varchar(6) NOT NULL,
  `building` enum('harvard','princeton','wharton','') NOT NULL,
  `owner` char(50) DEFAULT NULL,
  `status` enum('open','reserved','occupied') NOT NULL,
  PRIMARY KEY (`unitId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`unitId`, `building`, `owner`, `status`) VALUES
('5LM-E', 'princeton', 'Jeff Paswick', 'occupied'),
('5LN-E', 'wharton', NULL, 'open'),
('5LO-E', 'princeton', NULL, 'open'),
('5LE-E', 'harvard', NULL, 'open');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
