use marthagoshen;

select * from employee;

INSERT INTO 
	`marthagoshen`.`employee` (`email`, `firstname`, `lastname`, `position`) 
VALUES 
	('manongjuan@marthaservices.com', 'juan', 'cruz', 'maintenance');
