<?php
include "session-employee.php"
?>

<!DOCTYPE html>
<html lang="en-us">
    <head>
        <title>MARTHA GOSHENLAND</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="content=device-width", initial-scale="1">
        <meta author="John Raphael S. Apostol">
        <meta author="Jeff Danielle Paswick">
        <link rel="shortcut icon" href = "images/goshen.ico">
        
        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o" crossorigin="anonymous"></script>
        
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
        
        <!-- CSS link for side Menu -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <!-- /Css link for side menu -->
        
        <!--CSS Date Picker Link -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
        
        <!-- Inline CSS for Side Menu -->
        <style type="text/css">
            .table-wrapper {
                width: 300px;
                margin: 30px auto;
                background: #fff;
                padding: 20px;	
                box-shadow: 0 1px 1px rgba(0,0,0,.05);
            }
            
            .table-title {
                padding-bottom: 10px;
                margin: 0 0 10px;
            }
            
            .table-title h2 {
                margin: 6px 0 0;
                font-size: 22px;
            }
            
            .table-title .add-new {
                float: right;
                height: 30px;
                font-weight: bold;
                font-size: 12px;
                text-shadow: none;
                min-width: 100px;
                border-radius: 50px;
                line-height: 13px;
            }
            
            .table-title .add-new i {
                margin-right: 4px;
            }
            
            table.table {
                table-layout: fixed;
            }
            
            table.table tr th, table.table tr td {
                border-color: #e9e9e9;
            }
            
            table.table th i {
                font-size: 13px;
                margin: 0 5px;
                cursor: pointer;
            }
            
            table.table th:last-child {
                width: 100px;
            }
            
            table.table td a {
                cursor: pointer;
                display: inline-block;
                margin: 0 5px;
                min-width: 24px;
            }    
            
            table.table td a.add {
                color: #27C46B;
            }
            
            table.table td a.edit {
                color: #FFC107;
            }
            
            table.table td a.delete {
                color: #E34724;
            }
            
            table.table td i {
                font-size: 19px;
            }
            
            table.table td a.add i {
                font-size: 24px;
                margin-right: -1px;
                position: relative;
                top: 3px;
            }    
            
            table.table .form-control {
                height: 32px;
                line-height: 32px;
                box-shadow: none;
                border-radius: 2px;
            }
            
            table.table .form-control.error {
                border-color: #f50000;
            }
            
            table.table td .add {
                display: none;
            }
        </style>
        
        <!-- Inline CSS for tables -->
        <style type="text/css">
            .table-wrapper
        </style>
    </head>
    <body>
        <!-- Navigation Bar -->
        <nav class="navbar navbar-dark bg-dark">
            <a class="navbar-brand" href="#">Brand</a>
            <ul class="nav nav-pills">
                <li class="nav-item">
                    <a class="nav-link" href="Rent.php">Rent</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Utility.php">Utility</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="history.php">History</a>
                </li>
            </ul>
            <div class="pull-right">
            <a class="nav-link" href="login-employee.php">Logout</a>
                </div>
        </nav>
        
        <div class="divcontainer">
            <div class="row">
                
        <!-- Sidebar(Left) Navigation -->
                <div class="col-md-1">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="#">Building</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Residents</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Concerns</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Inventory</a>
                        </li>
                    </ul>
                </div>
        
        <!-- Table -->
                <!-- HTML code for table -->
        <div class="cold-md-10">
        <div class="container container-fluid">
            <div class="row">
        <div class="col-lg-12">
                <fieldset>
                    <legend>Table</legend>
                    <div class="table">
                        <table class="table table-stripped table-bordered">
                            <thead>
                                <tr>
                                    <th>Building</th>
                                    <th>Unit</th>
                                    <th>Date</th>
                                    <th>Total Amount Due</th>
                                    <th>Employee</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><a href="#">Daenerys</a></td>
                                    <td><a href="#">5LM</a></td>
                                    <td><a href="#">5/13/2019</a></td>
                                    <td><a href="#">5200</a></td>
                                    <td><a href="#">Employee</a></td>
                                    <td><a href="#">Good</a></td>
                                    <td>
                                        <a class="add" title="Add" data-toggle="tootltip"><i class="material-icons">&#xE03B;</i></a>
                                        <a class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                                        <a class="delete" title="Delete" data-toggle="tooltip"><i class="material-icons">&#xE872;</i></a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="pull-right">
                        <div class="table-title">
                            <div class="row">
                                <button type="button" class="btn btn-info add-new"><i class="fa fa-plus"></i> Add New</button>
                            </div>
                        </div>
                            </div>
                    </div>
                </fieldset>
            </div>
            </div>
        </div>
        </div>
        
            <!-- Sidebar(Right) Navigation -->
                    <div class="col-md-1">
                        <fieldset>
                            <legend>Select</legend>
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                <button id="btnShowModal" type="button" class="btn" data-target="#ModalAll"><a class="nav-link" href="#">All</a></button>
                                </li>
                                <li class="nav-item">
                                <button id="btnShowModal1" type="button" class="btn" data-target="#HarvardModal"><a class="nav-link" href="#">Harvard</a></button>
                                </li>
                                <li class="nav-item">
                                <button id="btnShowModal2" type="button" class="btn" data-target="#PrincetonModal"><a class="nav-link" href="#">Princeton</a></button>
                                </li>
                                <li class="nav-item">
                                <button id="btnShowModal3" type="button" class="btn" data-target="#WhartonModal"><a class="nav-link" href="#">Wharton</a></button>
                                </li>
                            </ul>
                        </fieldset>
                </div>
                
                <!-- First Modal For "All" -->
                    <div class="modal fade" id="ModalAll" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                            
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLongTitle">Generate Bill</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form class="dates navbar-left">
                                        <input type="text" autocomplete="off" id="user1" class="fomr-control" placeholder="yyy-mm-dd"/>
                                    </form>
                                    <form class="navbar-form navbar-right">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Search">
                                        </div>
                                        <button type="submit" class="btn btn-danger">Submit</button>
                                        </form>
                                    <div class="col-md-9">
                                        <div class="container text-center">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <table class="table table-striped table-bordered">
                                                        <thead>
															<tr class="active">
																<td>Building</td>
																<td>Unit</td>
																<td>Total Amount</td>
																<td> </td>
															</tr >
                                                        </thead>
														<tbody>
															<?php
																$sql = "select * from billing";
																$results = mysqli_query($connect, $sql);
																$queryResults = mysqli_num_rows($results);
											
																if($queryResults > 0){
																	while($row = mysqli_fetch_assoc($results)){
																		echo "<tr>
																			<td>".$row['building']."</td>
																			<td>".$row['unitId']."</td>
																			<td>".$row['totalamount']."</td>
																			</tr>";
																	}
																}
															?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button id="addRent" type="button" class="btn btn-success" data-target="#AddRent"><a class="nav-link" href="#">Add Rent</a></button>
                                    
                                    <button id="addInternet" type="button" class="btn btn-success" data-target="#AddInternet"><a class="nav-link" href="#">Add Internet Bill</a></button>
                                    
                                    <button id="removeBillAll" type="button" class="btn btn-success" data-target="#RemoveBillAll"><a class="nav-link" href="#">Remove Bill</a></button>
                                        
                                    <button id="removeInternetAll" type="button" class="btn btn-success" data-target="#RemoveInternetAll"><a class="nav-link" href="#">Remove Internet Bill</a></button>
                                        
                                    <button type="button" class="btn btn-secondary">Done</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                </div>
                            </div>
                        </div>
                </div>
        
            <!-- Second Modal For "Harvard" -->
                <div class="modal fade" id="HarvardModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                            
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Generate Bill</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                                <div class="modal-body">
                                    <form class="dates navbar-left">
                                        <input type="text" autocomplete="off" id="user1" class="fomr-control" placeholder="yyy-mm-dd"/>
                                    </form>
                                    <form class="navbar-form navbar-right">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Search">
                                        </div>
                                        <button type="submit" class="btn btn-danger">Submit</button>
                                        </form>
                                    <div class="col-md-9">
                                        <div class="container text-center">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <table class="table table-striped table-bordered">
                                                        <tr class="active">
                                                            <td>Building</td>
                                                            <td>Unit</td>
                                                            <td>Total Amount</td>
                                                            <td> </td>
                                                        </tr>
                                                        
                                                        <tbody>
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                    </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button id="addRentHarvard" type="button" class="btn btn-success" data-target="#AddRentHarvard"><a class="nav-link" href="#">Add Rent</a></button>
                                    
                                    <button id="addInternet1" type="button" class="btn btn-success" data-target="#AddInternetHarvard"><a class="nav-link" href="#">Add Internet Bill</a></button>
                                    
                                    <button id="removeBillHarvard" type="button" class="btn btn-success" data-target="#RemoveBillHarvard"><a class="nav-link" href="#">Remove Bill</a></button>
                                    
                                    <button id="removeInternetHarvard" type="button" class="btn btn-success" data-target="#RemoveInternetHarvard"><a class="nav-link" href="#">Remove Internet Bill</a></button>
                                    
                                    <button type="button" class="btn btn-secondary" >Done</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                </div>
                        </div>
                    </div>
                </div>
                
        
        <!-- Third Modal For "Princeton" -->
                <div class="modal fade" id="PrincetonModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                            
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Generate Bill</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                    <form class="dates navbar-left">
                                        <input type="text" autocomplete="off" id="user1" class="fomr-control" placeholder="yyy-mm-dd"/>
                                    </form>
                                    <form class="navbar-form navbar-right">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Search">
                                        </div>
                                        <button type="submit" class="btn btn-danger">Submit</button>
                                        </form>
                                    <div class="col-md-9">
                                        <div class="container text-center">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <table class="table table-striped table-bordered">
                                                        <tr class="active">
                                                            <td>Building</td>
                                                            <td>Unit</td>
                                                            <td>Total Amount</td>
                                                            <td> </td>
                                                        </tr>
                                                        
                                                        <tbody>
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button id="addRentPrinceton" type="button" class="btn btn-success" data-target="#AddRentPrinceton"><a class="nav-link" href="#">Add Rent</a></button>
                                    
                                    <button id="addInternet2" type="button" class="btn btn-success" data-target="#AddInternetPrinceton"><a class="nav-link" href="#">Add Internet Bill</a></button>
                                    
                                    <button id="removeBillPrinceton" type="button" class="btn btn-success" data-target="#RemoveBillPrinceton"><a class="nav-link" href="#">Remove Bill</a></button>
                                    
                                    <button id="removeInternetPrinceton" type="button" class="btn btn-success" data-target="#RemoveInternetPrinceton"><a class="nav-link" href="#">Remove Internet Bill</a></button>
                                    
                                    <button type="button" class="btn btn-secondary" >Done</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                </div>
                        </div>
                    </div>
                </div>
        
        <!-- Third Modal For "Wharton" -->
                <div class="modal fade" id="WhartonModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                            
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Generate Bill</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                    <form class="dates navbar-left">
                                        <input type="text" autocomplete="off" id="user1" class="fomr-control" placeholder="yyy-mm-dd"/>
                                    </form>
                                    <form class="navbar-form navbar-right">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Search">
                                        </div>
                                        <button type="submit" class="btn btn-danger">Submit</button>
                                        </form>
                                    <div class="col-md-9">
                                        <div class="container text-center">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <table class="table table-striped table-bordered">
                                                        <tr class="active">
                                                            <td>Building</td>
                                                            <td>Unit</td>
                                                            <td>Total Amount</td>
                                                            <td> </td>
                                                        </tr>
            
                                                        <tbody>
                                                        <tr >
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                            <td>#</td>
                                                        </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button id="addRentWharton" type="button" class="btn btn-success" data-target="#AddRentWharton"><a class="nav-link" href="#">Add Rent</a></button>
                                    
                                    <button id="addInternet3" type="button" class="btn btn-success" data-target="#AddInternetWharton"><a class="nav-link" href="#">Add Internet Bill</a></button>
                                    
                                    <button id="removeBillWharton" type="button" class="btn btn-success" data-target="#RemoveBillWharton"><a class="nav-link" href="#">Remove Bill</a></button>
                                    
                                    <button id="removeInternetWharton" type="button" class="btn btn-success" data-target="#RemoveInternetWharton"><a class="nav-link" href="#">Remove Internet Bill</a></button>
                                    
                                    <button type="button" class="btn btn-secondary" >Done</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        
        
        
        <!-- Bootstrap for Table Modal(All) Module -->
        <div class="modal fade" id="table1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Add Internet Fee</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <h3 for="form1">Are you sure you want to automatically add rent base on their building?</h3>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Yes</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        
        
        
        
        <!-- Boostrap for Remove Bill Items(All) -->
        <div class="modal fade" id="RemoveBillAll" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Remove Bill</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <h3 for="form1">Are you sure you want to permanently remove this bill in the list?</h3>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Yes</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Boostrap for Remove Bill Items(Harvard) -->
        <div class="modal fade" id="RemoveBillHarvard" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Remove Bill</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <h3 for="form1">Are you sure you want to permanently remove this bill in the list?</h3>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Yes</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Boostrap for Remove Bill Items(Princeton) -->
        <div class="modal fade" id="RemoveBillPrinceton" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Remove Bill</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <h3 for="form1">Are you sure you want to permanently remove this bill in the list?</h3>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Yes</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Boostrap for Remove Bill Items(Wharton) -->
        <div class="modal fade" id="RemoveBillWharton" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Remove Bill</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <h3 for="form1">Are you sure you want to permanently remove this bill in the list?</h3>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Yes</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Boostrap for Remove Internet Bill(All) -->
        <div class="modal fade" id="RemoveInternetAll" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Remove Bill</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <h3 for="form1">Are you sure you want to permanently remove this internet bill in the list?</h3>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Yes</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Boostrap for Remove Internet Bill(Harvard) -->
        <div class="modal fade" id="RemoveInternetHarvard" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Remove Bill</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <h3 for="form1">Are you sure you want to permanently remove this internet bill in the list?</h3>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Yes</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Boostrap for Remove Internet Bill(Princeton) -->
        <div class="modal fade" id="RemoveInternetPrinceton" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Remove Bill</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <h3 for="form1">Are you sure you want to permanently remove this internet bill in the list?</h3>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Yes</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Boostrap for Remove Internet Bill(Wharton) -->
        <div class="modal fade" id="RemoveInternetWharton" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Remove Bill</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <h3 for="form1">Are you sure you want to permanently remove this internet bill in the list?</h3>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Yes</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Bootstrap for Add Rent(All) Module -->
        <div class="modal fade" id="AddRentAll" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Add Internet Fee</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <h3 for="form1">Are you sure you want to automatically add rent base on their building?</h3>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Yes</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Bootstrap for Add Rent(Harvard) Module -->
        <div class="modal fade" id="AddRentHarvard" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Add Internet Fee</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <h3 for="form1">Are you sure you want to automatically add rent base on their building?</h3>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Yes</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>`
                </div>
            </div>
        </div>
        
        <!-- Bootstrap for Add Rent(Princeton) Module -->
        <div class="modal fade" id="AddRentPrinceton" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Add Internet Fee</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <h3 for="form1">Are you sure you want to automatically add rent base on their building?</h3>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Yes</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Bootstrap for Add Rent(Wharton) Module -->
        <div class="modal fade" id="AddRentWharton" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Add Internet Fee</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <h3 for="form1">Are you sure you want to automatically add rent base on their building?</h3>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Yes</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Bootstrap for AddInternet(All) Module -->
        <div class="modal fade" id="AddInternetAll" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Add Internet Fee</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <!-- Selection of items (Query) -->
                        <h4 for="form1">Units Selected</h4>
                        
                        <div class="md-form">
                              <label for="form2">Enter Amout</label>
                            <input type="text" id="form1" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Bootstrap for AddInternet(Harvard) Module -->
        <div class="modal fade" id="AddInternetHarvard" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Add Internet Fee</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <!-- Selection of items (Query) -->
                        <h4 for="form1">Units Selected</h4>
                        
                        <div class="md-form">
                              <label for="form2">Enter Amout</label>
                            <input type="text" id="form1" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Bootstrap for AddInternet(Princeton) Module -->
        <div class="modal fade" id="AddInternetPrinceton" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Add Internet Fee</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <!-- Selection of items (Query) -->
                        <h4 for="form1">Units Selected</h4>
                        
                        <div class="md-form">
                              <label for="form2">Enter Amout</label>
                            <input type="text" id="form1" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Bootstrap for AddInternet(Wharton) Module -->
        <div class="modal fade" id="AddInternetWharton" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Add Internet Fee</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <!-- Selection of items (Query) -->
                        <h4 for="form1">Units Selected</h4>
                        
                        <div class="md-form">
                              <label for="form2">Enter Amout</label>
                            <input type="text" id="form1" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </div>
        </div>
        
        
        <!-- JavaScript Files/Links -->
        <script src="js/bootstrap.min.js"></script>
        
        <!-- JavaScript Links includes Bootstrap -->
        <script src="js/bootstrap.bundle.min.js"></script>
            
        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
        
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
        
        <!-- Additional JavaScript Links -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        
        <!--Javascript Date Picker Link -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
        
        <!-- JavaScript code for the multiple Modals -->
        <script type="text/javascript">
            $(document).ready(function (){
                $('#btnShowModal').click(function(){
                    $('#ModalAll').modal('show');
            });
                $('#btnShowModal1').click(function(){
                    $('#HarvardModal').modal('show');
            });
                $('#btnShowModal2').click(function(){
                    $('#PrincetonModal').modal('show');
            });
                $('#btnShowModal3').click(function(){
                    $('#WhartonModal').modal('show');
            });
                
                $('#addInternet').click(function(){
                    $('#AddInternetAll').modal('show');
            });
                $('#addInternet1').click(function(){
                    $('#AddInternetHarvard').modal('show');
            });
                $('#addInternet2').click(function(){
                    $('#AddInternetPrinceton').modal('show');
            });
                $('#addInternet3').click(function(){
                    $('#AddInternetWharton').modal('show');
            });
                
                $('#addRent').click(function(){
                    $('#AddRentAll').modal('show');
            });
                $('#addRentHarvard').click(function(){
                    $('#AddRentHarvard').modal('show');
            });
                $('#addRentPrinceton').click(function(){
                    $('#AddRentPrinceton').modal('show');
            });
                $('#addRentWharton').click(function(){
                    $('#AddRentWharton').modal('show');
            });

                $('#removeBillAll').click(function(){
                    $('#RemoveBillAll').modal('show');
            });
                $('#removeBillHarvard').click(function(){
                    $('#RemoveBillHarvard').modal('show');
            });
                $('#removeBillPrinceton').click(function(){
                    $('#RemoveBillPrinceton').modal('show');
            });
                $('#removeBillWharton').click(function(){
                    $('#RemoveBillWharton').modal('show');
            });
                
                $('#removeInternetAll').click(function(){
                    $('#RemoveInternetAll').modal('show');
            });
                $('#removeInternetHarvard').click(function(){
                    $('#RemoveInternetHarvard').modal('show');
            });
                $('#removeInternetPrinceton').click(function(){
                    $('#RemoveInternetPrinceton').modal('show');
            });
                $('#removeInternetWharton').click(function(){
                    $('#RemoveInternetWharton').modal('show');
            });
        });
            
        </script>
        
        <!-- JavaSscript for Add/Edit/Delete for the table -->
        <script type="text/javascript">
            $(document).ready(function(){
                $('[data-toggle="tooltip"]').tooltip();
                var actions = $("table td:last-child").html();
                
                // Append table with add row form on Side Menu
                $(".add-new").click(function(){
                    $(this).attr("disabled", "disabled");
                    var index = $("table tbody tr:last-child").index();
                    var row = '<tr>' +
                        '<td><input type="text" class="form-control" name="name" id="name"></td>' + '<td><input type="text" class="form-control" name="name" id="name"></td>' + '<td><input type="text" class="form-control" name="name" id="name"></td>' + '<td><input type="text" class="form-control" name="name" id="name"></td>' + '<td><input type="text" class="form-control" name="name" id="name"></td>' + '<td><input type="text" class="form-control" name="name" id="name"></td>' +
                        '<td>' + actions + '</td>' +
                        '</tr>';
                    $("table").append(row);		
                    $("table tbody tr").eq(index + 1).find(".add, .edit").toggle();
                    $('[data-toggle="tooltip"]').tooltip();
                });
                
                // Add row on Side Menu
                $(document).on("click", ".add", function(){
                    var empty = false;
                    var input = $(this).parents("tr").find('input[type="text"]');
                    input.each(function(){
                        if(!$(this).val()){
                            $(this).addClass("error");
                            empty = true;
                        } else{
                            $(this).removeClass("error");
                        }
                    });
                    $(this).parents("tr").find(".error").first().focus();
                    if(!empty){
                        input.each(function(){
                            $(this).parent("td").html($(this).val());
                        });			
                        $(this).parents("tr").find(".add, .edit").toggle();
                        $(".add-new").removeAttr("disabled");
                    }		
                });
                
                // Edit row on Side Menu
                $(document).on("click", ".edit", function(){		
                    $(this).parents("tr").find("td:not(:last-child)").each(function(){
                        $(this).html('<input type="text" class="form-control" value="' + $(this).text() + '">');
                    });		
                    $(this).parents("tr").find(".add, .edit").toggle();
                    $(".add-new").attr("disabled", "disabled");
                });
    
                // Delete row on Side Menu
                $(document).on("click", ".delete", function(){
                    $(this).parents("tr").remove();
                    $(".add-new").removeAttr("disabled");
                })
            });
        </script>
        
        <!-- JavaScript for Date Picker -->
        <script>
            $(function(){ 
                $('.dates #user1').datepicker({
                    'fomat':'yyyy-mm-dd',
                    'autoclose' :true
                });
            });
        </script>
        
        <!-- Clickable Table Rows JQuery Code -->
        <script>
            document.addEventListener("DOMContentLoaded", () =>{
                const rows = document.querySelectorAll("tr[data-href]");
                
                rows.forEach(row => {
                    row.addEventListener("click", () =>{
                        window.location.href = row.dataset.href;
                    });
                });
            });
        </script>
        
        <!-- JavaScript code for Clickable Table row -->
        <script>
            $(function(){
                $('#modalTable1').modal({
                    keyboard: true,
                    backdrop: "static",
                    show:false,
                    
                }).on('show', function(){
                    var getIdFromRow = $(event.target).closest('tr').data('id');
                });
            });  
        </script>
        
    </body>
</html>  